'use client';

import React, { useEffect, useRef, useState } from 'react';
import AppLogo from '@/components/ui/AppLogo';
import { Bars3Icon, XMarkIcon } from '@heroicons/react/24/outline';

const navLinks = [
  { label: 'Program', href: '#program' },
  { label: 'Faculty', href: '#faculty' },
  { label: 'Curriculum', href: '#curriculum' },
  { label: 'Careers', href: '#careers' },
  { label: 'Contact', href: '#register' },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const headerRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (mobileOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [mobileOpen]);

  const handleNavClick = () => setMobileOpen(false);

  return (
    <>
      <header
        ref={headerRef}
        className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${
          scrolled ? 'nav-scrolled py-3' : 'py-5 bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 md:px-10 flex items-center justify-between">
          {/* Logo */}
          <a href="/" className="flex items-center gap-2.5 group">
            <AppLogo
              size={36}
              className="transition-transform duration-300 group-hover:scale-105"
            />
            <span className={`font-display text-xl font-semibold tracking-tight transition-colors duration-300 ${scrolled ? 'text-foreground' : 'text-white'}`}>
              Elwords Medical Writing Academy
            </span>
          </a>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-1">
            {navLinks?.map((link) => (
              <a
                key={link?.label}
                href={link?.href}
                className={`px-4 py-2 rounded-full text-[11px] font-semibold uppercase tracking-widest transition-all duration-200 ${
                  scrolled
                    ? 'text-muted-foreground hover:text-foreground hover:bg-secondary'
                    : 'text-white/80 hover:text-white hover:bg-white/10'
                }`}
              >
                {link?.label}
              </a>
            ))}
            <a
              href="#register"
              className="ml-4 px-5 py-2.5 rounded-full text-[11px] font-bold uppercase tracking-widest bg-primary text-primary-foreground hover:bg-accent transition-all duration-200 shadow-sm hover:shadow-md"
            >
              Enroll Now
            </a>
          </nav>

          {/* Mobile hamburger */}
          <button
            className={`md:hidden p-2 rounded-xl transition-colors ${scrolled ? 'text-foreground hover:bg-secondary' : 'text-white hover:bg-white/10'}`}
            onClick={() => setMobileOpen(true)}
            aria-label="Open navigation menu"
          >
            <Bars3Icon className="w-6 h-6" />
          </button>
        </div>
      </header>
      {/* Mobile Menu Overlay */}
      <div
        id="mobile-menu"
        className={`fixed inset-0 bg-background z-[60] flex flex-col justify-center items-center md:hidden ${mobileOpen ? 'open' : 'closed'}`}
        style={{ transform: mobileOpen ? 'translateY(0)' : 'translateY(-100%)' }}
      >
        <button
          className="absolute top-5 right-6 p-2 text-foreground hover:text-primary transition-colors"
          onClick={() => setMobileOpen(false)}
          aria-label="Close navigation menu"
        >
          <XMarkIcon className="w-7 h-7" />
        </button>

        <div className="flex items-center gap-2.5 mb-12">
          <AppLogo size={40} />
          <span className="font-display text-2xl font-semibold text-foreground">Elwords Medical Writing Academy</span>
        </div>

        <nav className="flex flex-col gap-6 text-center">
          {navLinks?.map((link) => (
            <a
              key={link?.label}
              href={link?.href}
              onClick={handleNavClick}
              className="text-2xl font-display font-light text-muted-foreground hover:text-primary transition-colors"
            >
              {link?.label}
            </a>
          ))}
          <a
            href="#register"
            onClick={handleNavClick}
            className="mt-4 px-8 py-3 rounded-full text-sm font-bold uppercase tracking-widest bg-primary text-primary-foreground hover:bg-accent transition-all duration-200"
          >
            Enroll Now
          </a>
        </nav>
      </div>
    </>
  );
}